package com.example.pose_detection_realtime

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
